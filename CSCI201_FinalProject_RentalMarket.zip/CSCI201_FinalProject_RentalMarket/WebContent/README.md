# HTML Webpages

## Content
* login.html: The login webpage
* market.html: The main market webpage
* newrequest.html: The new request form
* profile.html: Profile page
* requests.html: Requests page that show request content
* signup.html: The signup form

All these pages have been reviewed and are functional. Most of these pages use two css, where one of the css is meant to stylize the shell. Read the comments to see what needs to get dynamically created. Let us know on slack if there is any issues. There won't be much issue with functionality, but we may add some extra details if there is time.
